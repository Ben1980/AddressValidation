package demo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JButton;

import util.SimpleValidator;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class DemoKontaktDetailJFrame {

	private JFrame frame;
	private JTextField nameField;	
	private JLabel namesErrorLabel;
	private JButton saveButton;
	private JTextField firstNameField;
	private JLabel lblFirstname;
	private JLabel lblEmail;
	private JTextField emailField;
	private JLabel lblTelefon;
	private JTextField telNrField;
	private JLabel emailErrorLabel;
	private JLabel telNrErrorLabel;

	// TODO 3.3: Map your JTextFields to the internal names
	private JTextField getNameField()
	{
		return nameField;
	}
	private JTextField getFirstNameField()
	{
		return firstNameField; 
	}
	private JTextField getEMailField()
	{
		return emailField;
	}
	private JTextField getTelNr()
	{
		return telNrField;
	}	 
	
	// TODO 3.3:  Map your error labels to the internal names
	private JLabel getNamesErrorLabel()
	{
		return namesErrorLabel;
	}
	private JLabel getEMailErrorLabel()
	{
		return emailErrorLabel;
	} 
	
	private JLabel getTelNrErrorLabel()
	{
		return telNrErrorLabel;
	}	 

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DemoKontaktDetailJFrame window = new DemoKontaktDetailJFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DemoKontaktDetailJFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 291, 377);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		FocusListener saveCecker =  new CheckSaveableFocusListener();
			
		ImageIcon errorIcon = new ImageIcon(DemoKontaktDetailJFrame.class.getResource("/com/sun/java/swing/plaf/windows/icons/Error.gif"));
		
		JLabel lblKontaktDetails = new JLabel("Kontakt Details");
		lblKontaktDetails.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblKontaktDetails.setBounds(10, 15, 100, 17);
		frame.getContentPane().add(lblKontaktDetails);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(10, 47, 71, 14);
		frame.getContentPane().add(lblName);
		
		nameField = new JTextField();
		nameField.addFocusListener(saveCecker);
		nameField.setBounds(80, 43, 150, 20);
		frame.getContentPane().add(nameField);
		nameField.setColumns(10);

		namesErrorLabel = new JLabel(errorIcon);
		namesErrorLabel.setVisible(false);
		namesErrorLabel.setToolTipText("Vorname und Nachmame d�rfen nicht beide l sein");
		namesErrorLabel.setBounds(234, 50, 32, 32);
		frame.getContentPane().add(namesErrorLabel);
	
		JTextArea notesArea = new JTextArea();
		notesArea.setBounds(10, 180, 220, 119);
		frame.getContentPane().add(notesArea);
		
		saveButton = new JButton("Save");
		saveButton.setEnabled(false);
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("Saved record for: "+getNameField().getText()+" "+getFirstNameField().getText());
			}
		});
		saveButton.setBounds(10, 310, 89, 23);
		frame.getContentPane().add(saveButton);
		
		JLabel lblNotizen = new JLabel("Notizen:");
		lblNotizen.setBounds(10, 164, 71, 14);
		frame.getContentPane().add(lblNotizen);
		
		firstNameField = new JTextField();
		firstNameField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				checkSaveable();
			}
		});
		firstNameField.setColumns(10);
		firstNameField.setBounds(80, 68, 150, 20);
		frame.getContentPane().add(firstNameField);
		
		lblFirstname = new JLabel("Vorname:");
		lblFirstname.setBounds(10, 72, 71, 14);
		frame.getContentPane().add(lblFirstname);
		
		lblEmail = new JLabel("Email");
		lblEmail.setBounds(10, 99, 71, 14);
		frame.getContentPane().add(lblEmail);
		
		emailField = new JTextField();
		emailField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				checkSaveable();
			}
		});
		emailField.setColumns(10);
		emailField.setBounds(80, 95, 150, 20);
		frame.getContentPane().add(emailField);
		
		lblTelefon = new JLabel("Telefon");
		lblTelefon.setBounds(10, 128, 71, 14);
		frame.getContentPane().add(lblTelefon);
		
		telNrField = new JTextField();
		telNrField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				//char zero = '0';
				//int zeroKeyCode = zero;
				//char nine = '9';
				//int nineKeyCode = nine;
				//if(arg0.getKeyCode() >= zeroKeyCode && arg0.getKeyCode() <= nineKeyCode){
					checkSaveable();
				//}
			}
		});
		telNrField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				checkSaveable();
			}
		});
		telNrField.setColumns(10);
		telNrField.setBounds(80, 124, 150, 20);
		frame.getContentPane().add(telNrField);
		
		emailErrorLabel = new JLabel("New label");
		emailErrorLabel.setVisible(false);
		emailErrorLabel.setIcon(new ImageIcon(DemoKontaktDetailJFrame.class.getResource("/com/sun/java/swing/plaf/windows/icons/Error.gif")));
		emailErrorLabel.setBounds(234, 90, 31, 32);
		frame.getContentPane().add(emailErrorLabel);
		
		telNrErrorLabel = new JLabel("New label");
		telNrErrorLabel.setIcon(new ImageIcon(DemoKontaktDetailJFrame.class.getResource("/com/sun/java/swing/plaf/windows/icons/Error.gif")));
		telNrErrorLabel.setVisible(false);
		telNrErrorLabel.setBounds(234, 119, 31, 32);
		frame.getContentPane().add(telNrErrorLabel);
		
	}
	
	private boolean hasAtLeastOneName () {
		if (getNameField().getText().equals("") && getFirstNameField().getText().equals("")){
			getNamesErrorLabel().setVisible(true);
			return false;
		}else{
			getNamesErrorLabel().setVisible(false);
			return true;			
		}
	}

	private boolean isValidEmail () {
		if (SimpleValidator.isValidEmail(getEMailField().getText())) {
			getEMailErrorLabel().setVisible(false);
			return true;
		}else{
			getEMailErrorLabel().setVisible(true);
			return false;		
		}
	}


	private boolean validTelNr() {
		if (SimpleValidator.isValidTelNr(getTelNr().getText())) {
			getTelNrErrorLabel().setVisible(false);
			return true;
		}else{
			getTelNrErrorLabel().setVisible(true);
			return false;		
		}
	}

	private void checkSaveable() {
		Boolean isOk = hasAtLeastOneName();
		//TODO 3.4
		isOk = isValidEmail() && isOk; 
		isOk = validTelNr() && isOk;		
		//TODO 5.0
		saveButton.setEnabled(isOk);
	}
	
	
	private class CheckSaveableFocusListener extends FocusAdapter {
		@Override
		public void focusLost(FocusEvent arg0) {
			checkSaveable();
		}	
	}
}
